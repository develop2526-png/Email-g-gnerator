"use client";

import { Mail, CheckCircle, ArrowLeft } from "lucide-react";

export default function FreeToolsPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center gap-4">
          <a href="/dashboard" className="text-gray-600 hover:text-gray-800">
            <ArrowLeft className="w-6 h-6" />
          </a>
          <h1 className="text-xl font-bold">EmailPro</h1>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <aside className="w-64 bg-[#1a2332] min-h-[calc(100vh-73px)] text-white">
          <nav className="py-6">
            <div className="px-4">
              <h3 className="text-xs font-semibold text-gray-400 mb-3">
                MY FREE TOOLS
              </h3>
            </div>

            <div className="px-4 mt-8">
              <h3 className="text-xs font-semibold text-gray-400 mb-3">
                INFORMATION SUMMARY
              </h3>
              <div className="bg-gray-800 rounded-lg p-4 space-y-3">
                <div>
                  <p className="text-xs text-gray-400">Free User</p>
                </div>
                <div>
                  <p className="text-2xl font-bold">0</p>
                </div>
                <div>
                  <p className="text-sm">emailpro.us</p>
                </div>
                <div>
                  <p className="text-sm text-gray-300">user@gmail.com</p>
                </div>
              </div>
            </div>
          </nav>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-8">
          <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-2xl font-semibold mb-6 flex items-center gap-2">
              <Mail className="w-6 h-6" />
              MY FREE TOOLS
            </h2>

            {/* CC Generator Tools */}
            <div className="mb-8">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                <div className="border border-red-500 bg-red-50 rounded-lg p-4">
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className="font-semibold text-lg">CC GENERATOR V1</h3>
                      <p className="text-sm text-gray-600 mt-1">
                        Flat blue style | Easy to use
                      </p>
                    </div>
                    <div className="text-right text-sm text-gray-500">
                      <div>&lt;0</div>
                      <div>&lt;0</div>
                    </div>
                  </div>
                </div>

                <div className="border border-red-500 bg-red-50 rounded-lg p-4">
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className="font-semibold text-lg">CC GENERATOR V2</h3>
                      <p className="text-sm text-gray-600 mt-1">
                        Namso Gen style | Most popular one
                      </p>
                    </div>
                    <div className="text-right text-sm text-gray-500">
                      <div>&lt;0</div>
                      <div>&lt;0</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Tools List */}
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-gray-200 text-left text-sm text-gray-600">
                    <th className="pb-3 font-semibold">No</th>
                    <th className="pb-3 font-semibold">Name</th>
                    <th className="pb-3 font-semibold">Description</th>
                    <th className="pb-3 font-semibold">Live</th>
                    <th className="pb-3 font-semibold">Die</th>
                    <th className="pb-3 font-semibold">Status</th>
                  </tr>
                </thead>
                <tbody>
                  <tr className="border-b border-gray-100 hover:bg-gray-50">
                    <td className="py-4">1</td>
                    <td className="py-4">
                      <span className="text-blue-600">
                        1k Mailist Updates Daily
                      </span>
                    </td>
                    <td className="py-4 text-gray-600">
                      1000 Random emails (gmail, yahoo, hotmail) updates daily.
                    </td>
                    <td className="py-4 text-gray-500">&lt;0</td>
                    <td className="py-4 text-gray-500">&lt;0</td>
                    <td className="py-4">
                      <CheckCircle className="w-5 h-5 text-green-500" />
                    </td>
                  </tr>
                  <tr className="border-b border-gray-100 hover:bg-gray-50">
                    <td className="py-4">2</td>
                    <td className="py-4">
                      <span className="text-blue-600">Bin Checker</span>
                    </td>
                    <td className="py-4 text-gray-600">
                      Search, Check, Generate BINS just in one place. You must
                      try it, works like magic
                    </td>
                    <td className="py-4 text-gray-500">&lt;0</td>
                    <td className="py-4 text-gray-500">&lt;0</td>
                    <td className="py-4">
                      <CheckCircle className="w-5 h-5 text-green-500" />
                    </td>
                  </tr>
                  <tr className="border-b border-gray-100 hover:bg-gray-50">
                    <td className="py-4">3</td>
                    <td className="py-4">
                      <span className="text-blue-600">CC Extrap</span>
                    </td>
                    <td className="py-4 text-gray-600">
                      Free CC Extrap for all user. Expand Credit Card
                    </td>
                    <td className="py-4 text-gray-500">&lt;0</td>
                    <td className="py-4 text-gray-500">&lt;0</td>
                    <td className="py-4">
                      <CheckCircle className="w-5 h-5 text-green-500" />
                    </td>
                  </tr>
                  <tr className="border-b border-gray-100 hover:bg-gray-50">
                    <td className="py-4">4</td>
                    <td className="py-4">
                      <span className="text-blue-600">CC Generator</span>
                    </td>
                    <td className="py-4 text-gray-600">
                      Convert your bin number into credit card. Awesome tools
                    </td>
                    <td className="py-4 text-gray-500">&lt;0</td>
                    <td className="py-4 text-gray-500">&lt;0</td>
                    <td className="py-4">
                      <CheckCircle className="w-5 h-5 text-green-500" />
                    </td>
                  </tr>
                  <tr className="border-b border-gray-100 hover:bg-gray-50">
                    <td className="py-4">5</td>
                    <td className="py-4">
                      <span className="text-blue-600">Email Filter</span>
                    </td>
                    <td className="py-4 text-gray-600">
                      Filter your emails by domain name. Support up to 100k
                      emails without crash
                    </td>
                    <td className="py-4 text-gray-500">&lt;0</td>
                    <td className="py-4 text-gray-500">&lt;0</td>
                    <td className="py-4">
                      <CheckCircle className="w-5 h-5 text-green-500" />
                    </td>
                  </tr>
                  <tr className="border-b border-gray-100 hover:bg-gray-50">
                    <td className="py-4">6</td>
                    <td className="py-4">
                      <span className="text-blue-600">Fakedata Generator</span>
                    </td>
                    <td className="py-4 text-gray-600">
                      Generate fake address, temporary email, free for all user
                    </td>
                    <td className="py-4 text-gray-500">&lt;0</td>
                    <td className="py-4 text-gray-500">&lt;0</td>
                    <td className="py-4">
                      <CheckCircle className="w-5 h-5 text-green-500" />
                    </td>
                  </tr>
                  <tr className="border-b border-gray-100 hover:bg-gray-50">
                    <td className="py-4">7</td>
                    <td className="py-4">
                      <a
                        href="/tools/gmail-dot-trick"
                        className="text-blue-600 hover:underline"
                      >
                        Gmail dot Trick
                      </a>
                    </td>
                    <td className="py-4 text-gray-600">
                      General multi gmail account by your main account
                    </td>
                    <td className="py-4 text-gray-500">&lt;0</td>
                    <td className="py-4 text-gray-500">&lt;0</td>
                    <td className="py-4">
                      <CheckCircle className="w-5 h-5 text-green-500" />
                    </td>
                  </tr>
                  <tr className="border-b border-gray-100 hover:bg-gray-50">
                    <td className="py-4">8</td>
                    <td className="py-4">
                      <span className="text-blue-600">Google SQLI Scanner</span>
                    </td>
                    <td className="py-4 text-gray-600">
                      Scanning and get SQLI vulnerable sites with google dork
                    </td>
                    <td className="py-4 text-gray-500">&lt;0</td>
                    <td className="py-4 text-gray-500">&lt;0</td>
                    <td className="py-4">
                      <CheckCircle className="w-5 h-5 text-green-500" />
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
