"use client";

import { Mail, CreditCard, CheckCircle, Plus } from "lucide-react";

export default function DashboardPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <h1 className="text-xl font-bold">EmailPro</h1>
            <input
              type="text"
              placeholder="Search here..."
              className="w-64 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-2">
              <CreditCard className="w-5 h-5 text-gray-600" />
              <span className="text-sm font-semibold">CREDITS</span>
              <span className="bg-teal-500 text-white px-2 py-1 rounded text-sm">
                0
              </span>
            </div>
            <div className="flex items-center gap-2">
              <Mail className="w-5 h-5 text-gray-600" />
              <span className="text-sm font-semibold">ORDERS</span>
              <span className="bg-teal-500 text-white px-2 py-1 rounded text-sm">
                0
              </span>
            </div>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <aside className="w-64 bg-[#1a2332] min-h-[calc(100vh-73px)] text-white">
          <nav className="py-6">
            <div className="px-4 mb-6">
              <h3 className="text-xs font-semibold text-gray-400 mb-3">
                NAVIGATION
              </h3>
              <ul className="space-y-2">
                <li>
                  <a
                    href="/dashboard"
                    className="flex items-center gap-3 px-3 py-2 rounded hover:bg-gray-700"
                  >
                    <Mail className="w-5 h-5" />
                    <span>Dashboard</span>
                  </a>
                </li>
                <li>
                  <a
                    href="/free-tools"
                    className="flex items-center gap-3 px-3 py-2 rounded bg-gray-700"
                  >
                    <CheckCircle className="w-5 h-5" />
                    <span>Free Tools</span>
                    <span className="ml-auto bg-teal-500 text-white px-2 py-0.5 rounded text-xs">
                      ∞
                    </span>
                  </a>
                </li>
              </ul>
            </div>

            <div className="px-4 mt-8">
              <h3 className="text-xs font-semibold text-gray-400 mb-3">
                INFORMATION SUMMARY
              </h3>
              <div className="bg-gray-800 rounded-lg p-4 space-y-3">
                <div>
                  <p className="text-xs text-gray-400">Free User</p>
                </div>
                <div>
                  <p className="text-2xl font-bold">0</p>
                </div>
                <div>
                  <p className="text-sm">emailpro.us</p>
                </div>
                <div>
                  <p className="text-sm text-gray-300">user@gmail.com</p>
                </div>
              </div>
            </div>
          </nav>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-8">
          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <div className="bg-teal-500 text-white rounded-lg p-6">
              <div className="flex items-center gap-4">
                <div className="bg-white bg-opacity-20 p-3 rounded-lg">
                  <Mail className="w-8 h-8" />
                </div>
                <div>
                  <p className="text-sm opacity-90">REGISTERED EMAILS</p>
                  <p className="text-3xl font-bold">0</p>
                </div>
              </div>
              <div className="mt-4 flex justify-between text-sm">
                <span>TOTAL EMAILS: 0</span>
                <span>MEMBERS: 0</span>
              </div>
            </div>

            <div className="bg-red-500 text-white rounded-lg p-6">
              <div className="flex items-center gap-4">
                <div className="bg-white bg-opacity-20 p-3 rounded-lg">
                  <Mail className="w-8 h-8" />
                </div>
                <div>
                  <p className="text-sm opacity-90">STRIPE MERCHANT</p>
                  <p className="text-3xl font-bold">0 API</p>
                </div>
              </div>
              <div className="mt-4 flex justify-between text-sm">
                <span>VERY HIGH CHECK</span>
                <span className="bg-orange-600 px-2 py-1 rounded">
                  API EXCHANGE
                </span>
              </div>
            </div>

            <div className="bg-blue-600 text-white rounded-lg p-6">
              <div className="flex items-center gap-4">
                <div className="bg-white bg-opacity-20 p-3 rounded-lg">
                  <CreditCard className="w-8 h-8" />
                </div>
                <div>
                  <p className="text-sm opacity-90">MY CREDITS</p>
                  <p className="text-3xl font-bold">₽0</p>
                </div>
              </div>
              <div className="mt-4">
                <span className="text-sm">FREE USER = PAID USER</span>
                <span className="bg-orange-500 px-2 py-1 rounded text-xs ml-2">
                  ⚡ UPGRADE NOW!
                </span>
              </div>
            </div>

            <div className="bg-gray-800 text-white rounded-lg p-6">
              <div className="flex items-center gap-4">
                <div className="bg-white bg-opacity-10 p-3 rounded-lg">
                  <Plus className="w-8 h-8" />
                </div>
                <div>
                  <p className="text-sm opacity-90">MY INVITATION CODE</p>
                  <p className="text-3xl font-bold">0</p>
                </div>
              </div>
              <div className="mt-4 flex justify-between text-sm">
                <span>ACTIVE: 0</span>
                <span>USED: 0</span>
              </div>
            </div>
          </div>

          {/* Quick Access */}
          <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <Mail className="w-5 h-5" />
              Quick Access
            </h2>

            <div className="mb-4">
              <input
                type="text"
                placeholder="Search example (paypal, extr.ag, card)"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-gray-200 text-left text-sm text-gray-600">
                    <th className="pb-3 font-semibold">No</th>
                    <th className="pb-3 font-semibold">Name</th>
                    <th className="pb-3 font-semibold">Description</th>
                    <th className="pb-3 font-semibold">Live</th>
                    <th className="pb-3 font-semibold">Die</th>
                    <th className="pb-3 font-semibold">Status</th>
                  </tr>
                </thead>
                <tbody>
                  <tr className="border-b border-gray-100 hover:bg-gray-50">
                    <td className="py-4">1</td>
                    <td className="py-4">
                      <a
                        href="/tools/gmail-dot-trick"
                        className="text-blue-600 hover:underline"
                      >
                        Gmail dot Trick
                      </a>
                    </td>
                    <td className="py-4 text-gray-600">
                      Generate multiple gmail account by your main account
                    </td>
                    <td className="py-4 text-gray-500">&lt;0</td>
                    <td className="py-4 text-gray-500">&lt;0</td>
                    <td className="py-4">
                      <CheckCircle className="w-5 h-5 text-green-500" />
                    </td>
                  </tr>
                  <tr className="border-b border-gray-100 hover:bg-gray-50">
                    <td className="py-4">2</td>
                    <td className="py-4">
                      <a
                        href="/tools/email-validator"
                        className="text-blue-600 hover:underline"
                      >
                        Email Validator
                      </a>
                    </td>
                    <td className="py-4 text-gray-600">
                      Validate email addresses for deliverability
                    </td>
                    <td className="py-4 text-gray-500">&lt;0</td>
                    <td className="py-4 text-gray-500">&lt;0</td>
                    <td className="py-4">
                      <CheckCircle className="w-5 h-5 text-green-500" />
                    </td>
                  </tr>
                  <tr className="border-b border-gray-100 hover:bg-gray-50">
                    <td className="py-4">3</td>
                    <td className="py-4">
                      <span className="text-blue-600">Bin Checker</span>
                    </td>
                    <td className="py-4 text-gray-600">
                      Search, Check, Generate BINS just in one place
                    </td>
                    <td className="py-4 text-gray-500">&lt;0</td>
                    <td className="py-4 text-gray-500">&lt;0</td>
                    <td className="py-4">
                      <CheckCircle className="w-5 h-5 text-green-500" />
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
