export async function POST(request) {
  try {
    const body = await request.json();
    const { email } = body;

    if (!email) {
      return Response.json({ error: "Email is required" }, { status: 400 });
    }

    // Call the EMAIL_CHECK_2 integration
    const response = await fetch(
      `/integrations/email-check-2/v1/email/verify?email=${encodeURIComponent(email)}`,
      {
        method: "GET",
      },
    );

    if (!response.ok) {
      throw new Error("Failed to validate email");
    }

    const data = await response.json();

    return Response.json({
      email: data.email,
      status: data.status,
      reason: data.reason,
      isDeliverable: data.status === "deliverable",
      domain: data.domain,
      account: data.account,
      dns: data.dns,
      provider: data.provider,
    });
  } catch (error) {
    console.error("Error validating email:", error);
    return Response.json(
      { error: "Failed to validate email" },
      { status: 500 },
    );
  }
}
