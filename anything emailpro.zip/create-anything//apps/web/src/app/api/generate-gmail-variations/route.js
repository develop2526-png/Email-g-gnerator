export async function POST(request) {
  try {
    const body = await request.json();
    const { email, quantity } = body;

    if (!email) {
      return Response.json({ error: "Email is required" }, { status: 400 });
    }

    // Validate Gmail address
    if (!email.toLowerCase().endsWith("@gmail.com")) {
      return Response.json(
        { error: "Only Gmail addresses are supported" },
        { status: 400 },
      );
    }

    // Extract username (before @)
    const username = email.split("@")[0];

    // Remove any existing dots
    const cleanUsername = username.replace(/\./g, "");

    if (cleanUsername.length < 2) {
      return Response.json(
        { error: "Email username is too short" },
        { status: 400 },
      );
    }

    // Generate all possible dot combinations
    const variations = generateDotCombinations(cleanUsername);

    // Limit to requested quantity
    const limitedVariations = variations.slice(
      0,
      Math.min(quantity || 1000, variations.length),
    );

    // Add @gmail.com to each variation
    const emails = limitedVariations.map((v) => `${v}@gmail.com`);

    return Response.json({
      emails,
      total: emails.length,
      originalEmail: email,
    });
  } catch (error) {
    console.error("Error generating Gmail variations:", error);
    return Response.json(
      { error: "Failed to generate variations" },
      { status: 500 },
    );
  }
}

function generateDotCombinations(username) {
  const results = [];
  const len = username.length;

  // Calculate total possible combinations (2^(n-1) where n is username length)
  // We can place dots between any two characters
  const totalCombinations = Math.pow(2, len - 1);

  for (let i = 0; i < totalCombinations; i++) {
    let variation = "";
    for (let j = 0; j < len; j++) {
      variation += username[j];
      // Check if we should add a dot after this character
      // by checking the corresponding bit in the current combination number
      if (j < len - 1 && i & (1 << j)) {
        variation += ".";
      }
    }
    results.push(variation);
  }

  return results;
}
