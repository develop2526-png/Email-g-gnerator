"use client";

import { useState, useCallback } from "react";
import { Mail, ArrowLeft, Loader2 } from "lucide-react";

export default function GmailDotTrickPage() {
  const [email, setEmail] = useState("");
  const [quantity, setQuantity] = useState(200);
  const [generatedEmails, setGeneratedEmails] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleSubmit = useCallback(async () => {
    setError(null);
    setGeneratedEmails([]);

    if (!email) {
      setError("Please enter an email address");
      return;
    }

    // Validate Gmail address
    if (!email.toLowerCase().endsWith("@gmail.com")) {
      setError("Please enter a valid Gmail address (must end with @gmail.com)");
      return;
    }

    setLoading(true);

    try {
      const response = await fetch("/api/generate-gmail-variations", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ email, quantity }),
      });

      if (!response.ok) {
        throw new Error(`Error: ${response.statusText}`);
      }

      const data = await response.json();
      setGeneratedEmails(data.emails);
    } catch (err) {
      console.error(err);
      setError(err.message || "Failed to generate email variations");
    } finally {
      setLoading(false);
    }
  }, [email, quantity]);

  const handleCopy = useCallback(() => {
    const text = generatedEmails.join("\n");
    navigator.clipboard.writeText(text);
  }, [generatedEmails]);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center gap-4">
          <a href="/dashboard" className="text-gray-600 hover:text-gray-800">
            <ArrowLeft className="w-6 h-6" />
          </a>
          <h1 className="text-xl font-bold">EmailPro</h1>
          <input
            type="text"
            placeholder="Type something here..."
            className="flex-1 max-w-md px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <aside className="w-64 bg-[#1a2332] min-h-[calc(100vh-73px)] text-white">
          <nav className="py-6">
            <div className="px-4 mt-8">
              <h3 className="text-xs font-semibold text-gray-400 mb-3">
                INFORMATION SUMMARY
              </h3>
              <div className="bg-gray-800 rounded-lg p-4 space-y-3">
                <div>
                  <p className="text-xs text-gray-400">Free User</p>
                </div>
                <div>
                  <p className="text-2xl font-bold">0</p>
                </div>
                <div>
                  <p className="text-sm">emailpro.us</p>
                </div>
                <div>
                  <p className="text-sm text-gray-300">user@gmail.com</p>
                </div>
              </div>
            </div>
          </nav>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-8">
          <div className="bg-white rounded-lg shadow p-6 mb-6">
            <h2 className="text-2xl font-semibold mb-2 flex items-center gap-2">
              <Mail className="w-6 h-6" />
              Free Tools
            </h2>
            <div className="bg-gray-100 border-l-4 border-blue-500 p-4 mb-6">
              <h3 className="font-semibold text-lg flex items-center gap-2">
                <Mail className="w-5 h-5" />
                Gmail dot Trick
              </h3>
              <p className="text-sm text-gray-600 mt-1">
                Tips: Create a very long email address for maximal amounts.
              </p>
            </div>

            {/* Input Form */}
            <div className="border border-gray-300 rounded-lg p-6 mb-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                <div>
                  <label className="block text-sm font-semibold mb-2">
                    Email:
                  </label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="goleo782@gmail.com"
                    className="w-full px-4 py-2 bg-yellow-100 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold mb-2">
                    Quantity:
                  </label>
                  <input
                    type="number"
                    value={quantity}
                    onChange={(e) => setQuantity(parseInt(e.target.value) || 0)}
                    className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold mb-2">
                    Options:
                  </label>
                  <select className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500">
                    <option>GTrick V1</option>
                  </select>
                </div>
              </div>

              <button
                onClick={handleSubmit}
                disabled={loading}
                className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded font-semibold disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
              >
                {loading && <Loader2 className="w-4 h-4 animate-spin" />}
                Submit
              </button>

              {error && (
                <div className="mt-4 p-4 bg-red-50 border border-red-200 rounded text-red-700">
                  {error}
                </div>
              )}
            </div>

            {/* Results */}
            {generatedEmails.length > 0 && (
              <div>
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-semibold flex items-center gap-2">
                    <span className="bg-teal-500 text-white px-3 py-1 rounded text-sm">
                      RESULT
                    </span>
                    <span className="text-green-600 text-sm">
                      {generatedEmails.length}
                    </span>
                  </h3>
                  <button
                    onClick={handleCopy}
                    className="text-blue-600 hover:text-blue-700 text-sm font-semibold"
                  >
                    Copy All
                  </button>
                </div>

                <div className="border border-gray-300 rounded-lg p-4 bg-gray-50 max-h-96 overflow-y-auto">
                  {generatedEmails.map((emailVariation, index) => (
                    <div key={index} className="text-sm text-gray-700 py-1">
                      {emailVariation}
                    </div>
                  ))}
                  <div className="text-xs text-gray-500 mt-4 pt-4 border-t border-gray-300">
                    Forwarded to {email}
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Info Box */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
            <h3 className="font-semibold text-lg mb-3">
              How Gmail Dot Trick Works:
            </h3>
            <div className="space-y-2 text-sm text-gray-700">
              <p>
                <strong>1.</strong> Gmail ignores dots (.) in email addresses.
                So{" "}
                <span className="font-mono bg-white px-1">
                  john.doe@gmail.com
                </span>{" "}
                and{" "}
                <span className="font-mono bg-white px-1">
                  johndoe@gmail.com
                </span>{" "}
                go to the same inbox.
              </p>
              <p>
                <strong>2.</strong> This tool generates all possible dot
                combinations for your Gmail address.
              </p>
              <p>
                <strong>3.</strong> All generated email addresses will receive
                emails in your main Gmail inbox!
              </p>
              <p>
                <strong>4.</strong> Perfect for: signing up for multiple
                accounts, testing, or organizing emails.
              </p>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
