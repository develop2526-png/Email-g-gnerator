"use client";

import { useState, useCallback } from "react";
import { Mail, ArrowLeft, Loader2, CheckCircle, XCircle } from "lucide-react";

export default function EmailValidatorPage() {
  const [email, setEmail] = useState("");
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleValidate = useCallback(async () => {
    setError(null);
    setResult(null);

    if (!email) {
      setError("Please enter an email address");
      return;
    }

    setLoading(true);

    try {
      const response = await fetch("/api/validate-email", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ email }),
      });

      if (!response.ok) {
        throw new Error(`Error: ${response.statusText}`);
      }

      const data = await response.json();
      setResult(data);
    } catch (err) {
      console.error(err);
      setError(err.message || "Failed to validate email");
    } finally {
      setLoading(false);
    }
  }, [email]);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center gap-4">
          <a href="/dashboard" className="text-gray-600 hover:text-gray-800">
            <ArrowLeft className="w-6 h-6" />
          </a>
          <h1 className="text-xl font-bold">EmailPro</h1>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <aside className="w-64 bg-[#1a2332] min-h-[calc(100vh-73px)] text-white">
          <nav className="py-6">
            <div className="px-4 mt-8">
              <h3 className="text-xs font-semibold text-gray-400 mb-3">
                INFORMATION SUMMARY
              </h3>
              <div className="bg-gray-800 rounded-lg p-4 space-y-3">
                <div>
                  <p className="text-xs text-gray-400">Free User</p>
                </div>
                <div>
                  <p className="text-2xl font-bold">0</p>
                </div>
                <div>
                  <p className="text-sm">emailpro.us</p>
                </div>
                <div>
                  <p className="text-sm text-gray-300">user@gmail.com</p>
                </div>
              </div>
            </div>
          </nav>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-8">
          <div className="bg-white rounded-lg shadow p-6 mb-6">
            <h2 className="text-2xl font-semibold mb-2 flex items-center gap-2">
              <Mail className="w-6 h-6" />
              Free Tools
            </h2>
            <div className="bg-gray-100 border-l-4 border-green-500 p-4 mb-6">
              <h3 className="font-semibold text-lg flex items-center gap-2">
                <CheckCircle className="w-5 h-5" />
                Email Validator
              </h3>
              <p className="text-sm text-gray-600 mt-1">
                Check if an email address is valid and deliverable.
              </p>
            </div>

            {/* Input Form */}
            <div className="border border-gray-300 rounded-lg p-6 mb-6">
              <div className="mb-4">
                <label className="block text-sm font-semibold mb-2">
                  Email Address:
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="example@domain.com"
                  className="w-full px-4 py-2 bg-yellow-100 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-green-500"
                />
              </div>

              <button
                onClick={handleValidate}
                disabled={loading}
                className="bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded font-semibold disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
              >
                {loading && <Loader2 className="w-4 h-4 animate-spin" />}
                Validate Email
              </button>

              {error && (
                <div className="mt-4 p-4 bg-red-50 border border-red-200 rounded text-red-700">
                  {error}
                </div>
              )}
            </div>

            {/* Results */}
            {result && (
              <div>
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-semibold flex items-center gap-2">
                    <span className="bg-teal-500 text-white px-3 py-1 rounded text-sm">
                      VALIDATION RESULT
                    </span>
                    {result.isDeliverable ? (
                      <CheckCircle className="w-6 h-6 text-green-600" />
                    ) : (
                      <XCircle className="w-6 h-6 text-red-600" />
                    )}
                  </h3>
                </div>

                <div className="border border-gray-300 rounded-lg p-6 bg-gray-50">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm font-semibold text-gray-600">
                        Email:
                      </p>
                      <p className="text-lg">{result.email}</p>
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-gray-600">
                        Status:
                      </p>
                      <p
                        className={`text-lg font-semibold ${result.isDeliverable ? "text-green-600" : "text-red-600"}`}
                      >
                        {result.status}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-gray-600">
                        Reason:
                      </p>
                      <p className="text-lg">{result.reason}</p>
                    </div>
                    {result.provider && (
                      <div>
                        <p className="text-sm font-semibold text-gray-600">
                          Provider:
                        </p>
                        <p className="text-lg">{result.provider}</p>
                      </div>
                    )}
                  </div>

                  {result.domain && (
                    <div className="mt-6 pt-6 border-t border-gray-300">
                      <h4 className="font-semibold mb-3">
                        Domain Information:
                      </h4>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        <div>
                          <p className="text-sm text-gray-600">Domain Name:</p>
                          <p className="font-medium">{result.domain.name}</p>
                        </div>
                        <div>
                          <p className="text-sm text-gray-600">Accept All:</p>
                          <p className="font-medium">
                            {result.domain.acceptAll}
                          </p>
                        </div>
                        <div>
                          <p className="text-sm text-gray-600">Disposable:</p>
                          <p className="font-medium">
                            {result.domain.disposable}
                          </p>
                        </div>
                        <div>
                          <p className="text-sm text-gray-600">
                            Free Provider:
                          </p>
                          <p className="font-medium">{result.domain.free}</p>
                        </div>
                      </div>
                    </div>
                  )}

                  {result.dns && (
                    <div className="mt-4 pt-4 border-t border-gray-300">
                      <h4 className="font-semibold mb-3">DNS Information:</h4>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        <div>
                          <p className="text-sm text-gray-600">Type:</p>
                          <p className="font-medium">{result.dns.type}</p>
                        </div>
                        <div>
                          <p className="text-sm text-gray-600">Record:</p>
                          <p className="font-medium">{result.dns.record}</p>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* Info Box */}
          <div className="bg-green-50 border border-green-200 rounded-lg p-6">
            <h3 className="font-semibold text-lg mb-3">
              About Email Validation:
            </h3>
            <div className="space-y-2 text-sm text-gray-700">
              <p>
                <strong>1.</strong> This tool checks if an email address is
                valid and can receive emails.
              </p>
              <p>
                <strong>2.</strong> It verifies the domain, DNS records, and
                mailbox availability.
              </p>
              <p>
                <strong>3.</strong> Helps you maintain clean email lists and
                reduce bounce rates.
              </p>
              <p>
                <strong>4.</strong> Perfect for: verifying user signups,
                cleaning mailing lists, or validating contact forms.
              </p>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
